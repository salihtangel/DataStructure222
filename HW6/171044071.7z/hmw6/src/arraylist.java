import java.util.ArrayList;


public class arraylist {



    private ArrayList a = new ArrayList();

    public void  Deneme(){
        getA().add(5);


    }

    public ArrayList getA() {
        return a;
    }
}
