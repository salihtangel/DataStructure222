import java.util.Iterator;

/**
 * for password i crated it but not working
 */
public class Data {
    private  Integer ID[][] ;
    private  Integer Password[][];


    public Data(Integer[][] ID, Integer[][] password) {
        this.ID = ID;
        Password = password;
    }



    public Integer getID(int i,int j) {
        return ID[i][j];
    }

    public void setID(Integer[][] ID) {
        this.ID = ID;
    }

    public Integer getPassword(int i,int j) {
        return Password[i][j];
    }

    public void setPassword(Integer[][] password) {
        Password = password;
    }
    public void Iterator(){

    }
}


