

import com.sun.tools.javac.Main;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Objects;

public class ReadCSVExample1
{
    /***
     * Creating an arraylist for use
     */

    // Function to remove duplicates from an ArrayList
    public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list)
    {

        // Create a new ArrayList
        ArrayList<T> newList = new ArrayList<T>();

        // Traverse through the first list
        for (T element : list) {

            // If this element is not present in newList
            // then add it
            if (!newList.contains(element)) {

                newList.add(element);
            }
        }

        // return the new list
        return newList;
    }

    /**
     * read file and record as trader ordes
     * @throws IOException
     */
    public void read() throws IOException {
        ArrayList<String>  s1= new ArrayList<String>();
        FileWriter myWriter = new FileWriter("filename.txt");

        String line = "";
        String splitBy = ";";
        //record traders
        try
        {
            //parsing a CSV file into BufferedReader class constructor
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\tangel\\IdeaProjects\\hmw6\\e-commerce-samples.csv"));
            while ((line = br.readLine()) != null)   //returns a Boolean value
            {
                String[] employee = line.split(splitBy);    // use comma as separator
                s1.add(employee[6]);
                //System.out.println(employee[6] + "\n");
                // System.out.println("Employee [First Name=" + employee[0] + ", Last Name=" + employee[1] + ", Designation=" + employee[2] + ", Contact=" + employee[3] + ", Salary= " + employee[4] + ", City= " + employee[5] +"]");



            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }




        //first index is trader name
        s1.remove(0);

        int size = removeDuplicates(s1).size();



        ArrayList<String> s3 = new ArrayList<>((removeDuplicates(s1)));


        for(int i=0;i<size;i++){
            //System.out.println(removeDuplicates(s1).get(3000));

            try
            {

                //parsing a CSV file into BufferedReader class constructor
                BufferedReader br = new BufferedReader(new FileReader("e-commerce-samples.csv"));
                while ((line = br.readLine()) != null)   //returns a Boolean value
                {

                    String[] employee = line.split(splitBy);    // use comma as separator


                    //System.out.println("second\t"+(employee[6]));
                    if((Objects.equals(employee[6], s3.get(i))) ) {

                        try {
                            myWriter.write(Arrays.toString(employee));
                            myWriter.write("\n");

                        } catch (IOException e) {
                            System.out.println("An error occurred.");
                            e.printStackTrace();
                        }

                    }

                    // System.out.println(employee[6] + "\n");
                    // System.out.println("Employee [First Name=" + employee[0] + ", Last Name=" + employee[1] + ", Designation=" + employee[2] + ", Contact=" + employee[3] + ", Salary= " + employee[4] + ", City= " + employee[5] +"]");



                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }


        }

        myWriter.close();//close writer


    }


}




