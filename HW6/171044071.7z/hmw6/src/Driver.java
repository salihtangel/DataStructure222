
import java.io.IOException;
import java.util.*;

/**
 * Author salih tangel
 */
public class Driver {
    public static void main(String[] args) throws IOException {
/*
        //@TODO/arraylist change it//
        arraylist b = new arraylist();
        b.Deneme();

        // Create an iterator for the list
        // using iterator() method
        Iterator<Integer> iter= b.getA().iterator();

        // Displaying the values after iterating
        // through the list
        System.out.println("\nThe iterator values" + " of arraylist are: ");
        while (iter.hasNext()) {
            System.out.print(iter.next() + " ");
        }


        //@ Creating an empty LinkedList


        LinkedList<String> list = new LinkedList<String>();

        // Use add() method to add elements in the list
        list.add("Geeks");
        list.add("for");
        list.add("Geeks");
        list.add("10");
        list.add("20");
        // Displaying the linkedlist

       // System.out.println("LinkedList:" + list);

        // Setting the ListIterator at a specified position
        ListIterator list_Iter = list.listIterator(0);

        // Iterating through the created list from the position
        System.out.println("The list is as follows:");
        while(list_Iter.hasNext()){
            System.out.println(list_Iter.next());
        }

        // @Create Queue



        PriorityQueue<String> a = new PriorityQueue<String>();

        a.add("ahmet");
        a.add("mehmet");
        a.add("salih");

        System.out.println("\n"+ a);
        Iterator  value =  a.iterator();
        while(value.hasNext()){
            System.out.println(value.next());
        }

        //@Hastable

        Hashtable<Integer, String> ht1 = new Hashtable<>();

        // Initialization of a Hashtable
        // using Generics
        Hashtable<Integer, String> ht2
                = new Hashtable<Integer, String>();

        // Inserting the Elements
        // using put() method
        ht1.put(1, "one");
        ht1.put(2, "two");
        ht1.put(3, "three");

        ht2.put(4, "four");
        ht2.put(5, "five");
        ht2.put(6, "six");

        // Print mappings to the console
        System.out.println("Mappings of ht1 : " + ht1);
        System.out.println("Mappings of ht2 : " + ht2);
*/

        ReadCSVExample1 deneme = new ReadCSVExample1();
        deneme.read();


    }
}
