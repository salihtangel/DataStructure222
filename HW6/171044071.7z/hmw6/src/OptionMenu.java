/**
 * i tried a menu but since i could not completed others no need to do it
 */
/*
import java.util.*;

public class OptionMenu {



    public static void main(String [] args){

        // Display the men
        Scanner in_first = new Scanner(System.in);
        Scanner in_second = new Scanner(System.in);

        Scanner in_third = new Scanner(System.in);
        System.out.println("1\t Java Programming");
        System.out.println("2\t Soft Engineering");
        System.out.println("3\t Requirement Engineering");
        System.out.println("4\t Project Management");

        System.out.println("Please enter your choice:");

        //Get user's choice
        Integer one[][]={{0}};
        Integer two[][]={{0}};
        Data x = new Data(one,two);

        int deneme[][]={{031232},{113232},{232132}};
        int i=0;
        for (int num[]: deneme) {
                System.out.println(num[0]);

        }
       int id = in_first.nextInt() ;
        int password= in_second.nextInt();
       // System.out.println(x.getID(0,0));
        */
/*for (int number:x.getID() ) {

        }
*//*



      */
/*  Iterator a = x;
        if(x.getID() == id && x.getPassword() == password){

            System.out.println("input success");
        }else{System.out.println("input false"); }
*//*


        int choice =in_third.nextInt();

        //Display the title of the chosen module
        switch (choice) {
            case 1: System.out.println("Java Programming");
                break;
            case 2: System.out.println("Soft Engineering");
                break;
            case 3: System.out.println("Req Engineering");
                break;
            case 4: System.out.println("Proj Management");
                break;
            default: System.out.println("Invalid choice");
        }//end of switch

        */
/*String[] denemesa ={"sas"+"sasasa"};
        System.out.println("salih burasiii " + Arrays.toString(denemesa));*//*

 }//end of the main method

}//end of class*/
