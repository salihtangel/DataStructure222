


/**
 /* My hybritlist class it takes linklist and linklist generic is arraylist
 */

public class HybridList {




    private KWLinkedList<KWArrayList<Data>> list = new KWLinkedList<>();

    public int getSize() {
        return list.getSize();
    }


    /**
     /* Add function
     /*@param st it takes an objet and add object to arraylsit if not create an arraylist
     */


    public void add(Data st) {

        if (this.list.getSize() > 0) {
            if (this.list.getLast().add(st) == false) { //constant

                KWArrayList<Data> nw = new KWArrayList<>(); //constant
                nw.add(st);
                this.list.addLast(nw);
                //System.out.println(this.list.getSize());

            }

        } else {

            KWArrayList<Data> nw = new KWArrayList<>();
            nw.add(st);
            this.list.addLast(nw);


        }

    }

    /**
     /* remoce function
     /*@param  it takes an objet and remove object from arraylsit if arraylist is empty it removes linklis node
     */


    public void remove(Data st) {

        KWLinkedList.KWListIter it = this.list.listIterator();//constant
        int counter = 0;

        while (it.hasNext()) {   //n^2

            KWArrayList<Data> ls = (KWArrayList<Data>) it.next();
            for (int i = 0; i < ls.getSize(); i++) {//n
                if (ls.get(i).equals(st)) {
                    ls.remove(i);
                    if (ls.getSize() == 0) {
                        this.list.remove(counter);
                        break;
                    }
                }

            }
            counter++;

        }

    }

    /**
     * print all is printing all linklist nodes
     */
    public void printall() {

        KWLinkedList.KWListIter it = this.list.listIterator();//constant
        int counter = 0;

        while (it.hasNext()) {   //n^2
            KWArrayList<Data> ls = (KWArrayList<Data>) it.next();
            for (int i = 0; i < ls.getSize(); i++) {//n
                System.out.println("arraylist of "+ i +" th element");
                System.out.println("Admin: " +ls.get(i).getAdmin() +" Furniture: "+ls.get(i).getFurniture() +" Branch: " +ls.get(i).getBranch() +" Customer: "+ ls.get(i).getCustomer()+ " EmployeeNum: "+ls.get(i).getEmployeeNumber() + " FurnitureNum: "+ ls.get(i).getFurnitureNumber() + " CustomerNum: "+ ls.get(i).getCustomerNumber() +" BranchNum: "+ ls.get(i).getBranchNumber());

            }
            counter++;

        }

    }

    }





