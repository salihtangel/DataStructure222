import java.util.Arrays;
/** This class implements some of the methods of the Java ArrayList class. It
 does not implement the List interface.
 */

/** Main olmadiginda class eklenemiyo cunku sen main class olarak compile edebiliyosun diger turlu eklemeyi ogren
  */
// Koffman-c02.indd 70 10/30/2015 7:38:59 PM2.4 Implementation of an ArrayList Class 71
public class KWArrayList<E> {
    // Data Fields
    /**
     * The default initial capacity
     */
    private static final int INITIAL_CAPACITY = 5;
    /**
     * The underlying data array
     */
    private E[] theData;
    /**
     * The current size
     */
    private int size = 0;
    /**
     * The current capacity
     */
    private int capacity = 0;

    /**Constructor*/
    public KWArrayList() {
        capacity = INITIAL_CAPACITY;
        theData = (E[]) new Object[capacity];
    }
    /** Add method*/
    public boolean add(E anEntry) {
        if (size == capacity) {
            // @TODOdolunca false donucek

            return false;
            // reallocate();//gidecek
        }

        theData[size] = anEntry;
        size++;
        return true;
    }
    /**Other add method it is with index*/
    public boolean add(int index, E anEntry) {
        if (index < 0 || index > size) { //@TODOsize ve capacity degisecek
            throw new ArrayIndexOutOfBoundsException(index);//simdilik kalsin
        }
        if (size == capacity) {
            // finished array
            return false;
        }

        for (int i = size; i > index; --i) {
            theData[i] = theData[i-1];
        }
        // Insert the new item.
        theData[index] = anEntry;
        size++;
        return true;
    }
    /**get method */
    public E get(int index) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        return theData[index];
    }
    /** set method*/
    public E set(int index, E newValue) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
        E oldValue = theData[index];
        theData[index] = newValue;
        return oldValue;
    }
    /**remove method*/
    public E remove(int index) {
        if (size ==0 ) { // SIZE SIFIRSA NULL DONDUR
            return null;//throw olmicak return null pointer bosalmis demek arraylisti sil
        }
        E returnValue = theData[index];
        for (int i = index + 1; i < size; i++) {
            theData[i - 1 ] = theData[i];
        }
        --size;
        return returnValue;
    }
    /**reallocate */
    private void reallocate() {
        capacity = 2 * capacity;
        theData = Arrays.copyOf(theData, capacity);
    }
    public int getSize(){

        return size;
    }



}

