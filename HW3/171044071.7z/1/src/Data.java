import java.util.Objects;

public class Data {

    /**
     * Getters and Setters for the administrator with name,furniture,branch,customers.
     /* Data is my Main Class.
     *
     */
    private String  admin;
    private String furniture;
    private String branch;
    private String customer;

    private int employeeNumber;
    private int furnitureNumber;
    private int branchNumber;
    private int custumerNumber;

    public Data(String admin, String furniture, String branch, String customer, int employeeNumber, int furnitureNumber, int branchNumber, int custumerNumber) {
        this.admin=admin;
        this.furniture=furniture;
        this.branch=branch;
        this.customer=customer;

        this.employeeNumber = employeeNumber;
        this.furnitureNumber = furnitureNumber;
        this.branchNumber = branchNumber;
        this.custumerNumber = custumerNumber;
    }


    /**
     * Getters
     */
    public String getAdmin() {
        return admin;
    }
    public String getFurniture() {
        return furniture;
    }
    public String getBranch() {
        return branch;
    }
    public String getCustomer() {
        return customer;
    }

    public int getEmployeeNumber() {
        return employeeNumber;
    }
    public int getFurnitureNumber() {
        return furnitureNumber;
    }
    public int getBranchNumber() {
        return branchNumber;
    }
    public int getCustomerNumber() {
        return custumerNumber;
    }




    /*
    public void setAdmin(String admin) {
        this.admin = admin;
    }

    public void setFurniture(String furniture) {
        this.furniture = furniture;
    }
    public void setBranch(String branch) {
        this.branch = branch;
    }
    public void setCustomer(String customer) {
        this.customer = customer;
    }

    public void setFurnitureNumber(int furnitureNumber) {
        this.furnitureNumber = furnitureNumber;
    }
    public void setEmployeeNumber(int employeeNumber) {
        this.employeeNumber = employeeNumber;
    }
    public void setBranchNumber(int branchNumber) {
        this.branchNumber = branchNumber;
    }
    public void setCustumerNumber(int custumerNumber) {
        this.custumerNumber = custumerNumber;
    }
*/
    /**
     * Equals for check is equal in automotion
     * @param o take object and chek whether is equal or not
     * @return employee and branch information
     */

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Data data = (Data) o;
        return employeeNumber == data.employeeNumber && furnitureNumber == data.furnitureNumber && branchNumber == data.branchNumber && custumerNumber == data.custumerNumber && admin.equals(data.admin) && furniture.equals(data.furniture) && branch.equals(data.branch) && customer.equals(data.customer);
    }

    @Override
    public int hashCode() {
        return Objects.hash(admin, furniture, branch, customer, employeeNumber, furnitureNumber, branchNumber, custumerNumber);
    }
}
