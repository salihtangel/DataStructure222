
/**
 *
 * Driver .
 *
 */
public class Driver {


    public static void main(String[] args) {

        HybridList hlist= new HybridList();



        Data obj1=new Data("Salih","Office Chair","magaza1","cem",0,0,0,0);
        Data obj2=new Data("Cengiz","Office Desk","magaza2","can",0,1,1,1);
        Data obj3= new Data("Ali","Meting Table","magaza2","can",0,2,1,1);
        Data obj4=  new Data("Ahmet","Bookcase","magaza2","can",0,3,1,1);
        Data obj5= new Data("Mehmet","Office Bookcase","magaza2","can",0,4,1,1);
        Data obj6= new Data("Mehmet","Office Bookcase","magaza2","can",0,4,1,1);


        System.out.println("Inial capacity is 5 ");
        System.out.println("size of linklist "+hlist.getSize());

        hlist.add(obj1);
        hlist.add(obj2);
        hlist.add(obj3);
        hlist.add(obj4);
        hlist.add(obj5);

        hlist.add(obj6);
        System.out.println("After adding 6 element my new size of linkedlist");
        System.out.println("size of linklist "+hlist.getSize());
        System.out.println("\nPrinting Arraylist:");
        hlist.printall();




        //sondan siliyo
        hlist.remove(obj6);
        System.out.println("After removing last element in linkedlist my new size of linkedlist");
        System.out.println("size of linklist "+hlist.getSize());



        hlist.remove(obj5);
        hlist.remove(obj4);
        hlist.remove(obj3);
        hlist.remove(obj2);
        hlist.remove(obj1);

        System.out.println("\nAfter removing all element in linkedlist my new size of linkedlist");
        System.out.println("size of linklist "+hlist.getSize());
        System.out.println("Printing Arraylist:");
        hlist.printall();








    }

}
